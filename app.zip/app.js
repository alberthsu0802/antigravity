// ===== Health Tracker AI - Main JavaScript =====

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    // Set current date/time in forms
    setCurrentDateTime();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Initialize charts
    initializeCharts();
    
    // Load saved data
    loadHealthData();
    
    // Initialize smooth scrolling
    initializeSmoothScroll();
}

// ===== Date/Time Initialization =====
function setCurrentDateTime() {
    const dateInput = document.getElementById('dateInput');
    const timeInput = document.getElementById('timeInput');
    
    if (dateInput && timeInput) {
        const now = new Date();
        dateInput.valueAsDate = now;
        timeInput.value = now.toTimeString().slice(0, 5);
    }
}

// ===== Event Listeners =====
function initializeEventListeners() {
    // Hero CTA buttons
    const startTrackingBtn = document.getElementById('startTrackingBtn');
    const learnMoreBtn = document.getElementById('learnMoreBtn');
    
    if (startTrackingBtn) {
        startTrackingBtn.addEventListener('click', () => {
            scrollToSection('tracking');
        });
    }
    
    if (learnMoreBtn) {
        learnMoreBtn.addEventListener('click', () => {
            scrollToSection('dashboard');
        });
    }
    
    // Health tracking form
    const healthForm = document.getElementById('healthTrackingForm');
    if (healthForm) {
        healthForm.addEventListener('submit', handleHealthFormSubmit);
    }
    
    // Plan creator form
    const planForm = document.getElementById('planCreatorForm');
    if (planForm) {
        planForm.addEventListener('submit', handlePlanFormSubmit);
    }
    
    // AI analysis refresh
    const refreshBtn = document.getElementById('refreshAnalysisBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', refreshAIAnalysis);
    }
    
    // Plan detail modal
    const viewPlanBtns = document.querySelectorAll('.view-plan-btn');
    viewPlanBtns.forEach(btn => {
        btn.addEventListener('click', () => openPlanModal(btn.dataset.planId));
    });
    
    const closePlanModal = document.getElementById('closePlanModal');
    if (closePlanModal) {
        closePlanModal.addEventListener('click', () => closeModal('planDetailModal'));
    }
    
    // Modal overlay click to close
    const modalOverlay = document.querySelector('.modal-overlay');
    if (modalOverlay) {
        modalOverlay.addEventListener('click', () => closeModal('planDetailModal'));
    }
    
    // Schedule tabs
    const scheduleTabs = document.querySelectorAll('.schedule-tab');
    scheduleTabs.forEach(tab => {
        tab.addEventListener('click', () => switchScheduleTab(tab.dataset.tab));
    });
    
    // Navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            scrollToSection(targetId);
            
            // Update active state
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });
}

// ===== Smooth Scrolling =====
function initializeSmoothScroll() {
    // Update navbar on scroll
    window.addEventListener('scroll', () => {
        const navbar = document.getElementById('navbar');
        if (window.scrollY > 100) {
            navbar.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.boxShadow = 'none';
        }
    });
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const navbarHeight = document.getElementById('navbar').offsetHeight;
        const targetPosition = section.offsetTop - navbarHeight;
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// ===== Health Form Handling =====
function handleHealthFormSubmit(e) {
    e.preventDefault();
    
    const formData = {
        date: document.getElementById('dateInput').value,
        time: document.getElementById('timeInput').value,
        weight: document.getElementById('weightInput').value,
        height: document.getElementById('heightInput').value,
        bloodPressureSys: document.getElementById('bloodPressureSys').value,
        bloodPressureDia: document.getElementById('bloodPressureDia').value,
        heartRate: document.getElementById('heartRateInput').value,
        sleepHours: document.getElementById('sleepHoursInput').value,
        steps: document.getElementById('stepsInput').value,
        notes: document.getElementById('notesInput').value
    };
    
    // Save to localStorage
    saveHealthRecord(formData);
    
    // Show success message
    showNotification('健康記錄已成功儲存！', 'success');
    
    // Reset form
    e.target.reset();
    setCurrentDateTime();
    
    // Update dashboard
    updateDashboard();
    
    // Update recent records
    displayRecentRecords();
}

function saveHealthRecord(record) {
    let records = JSON.parse(localStorage.getItem('healthRecords') || '[]');
    records.unshift({
        ...record,
        id: Date.now(),
        timestamp: new Date().toISOString()
    });
    
    // Keep only last 100 records
    if (records.length > 100) {
        records = records.slice(0, 100);
    }
    
    localStorage.setItem('healthRecords', JSON.stringify(records));
}

function loadHealthData() {
    displayRecentRecords();
    updateDashboard();
}

function displayRecentRecords() {
    const recordsList = document.getElementById('recordsList');
    if (!recordsList) return;
    
    const records = JSON.parse(localStorage.getItem('healthRecords') || '[]');
    
    if (records.length === 0) {
        recordsList.innerHTML = '<p style="text-align: center; color: var(--gray-500); padding: 2rem;">尚無記錄</p>';
        return;
    }
    
    recordsList.innerHTML = records.slice(0, 5).map(record => `
        <div class="record-item" style="padding: 1rem; background: var(--gray-50); border-radius: var(--radius-md); margin-bottom: 0.75rem;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <strong style="color: var(--primary-600);">${record.date} ${record.time}</strong>
                <button onclick="deleteRecord(${record.id})" style="background: none; border: none; color: var(--error); cursor: pointer; font-size: 1.25rem;">×</button>
            </div>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; font-size: 0.875rem;">
                ${record.weight ? `<div>體重: <strong>${record.weight} kg</strong></div>` : ''}
                ${record.heartRate ? `<div>心率: <strong>${record.heartRate} bpm</strong></div>` : ''}
                ${record.sleepHours ? `<div>睡眠: <strong>${record.sleepHours} 小時</strong></div>` : ''}
                ${record.steps ? `<div>步數: <strong>${record.steps} 步</strong></div>` : ''}
            </div>
            ${record.notes ? `<p style="margin-top: 0.5rem; font-size: 0.875rem; color: var(--gray-600);">${record.notes}</p>` : ''}
        </div>
    `).join('');
}

function deleteRecord(id) {
    let records = JSON.parse(localStorage.getItem('healthRecords') || '[]');
    records = records.filter(r => r.id !== id);
    localStorage.setItem('healthRecords', JSON.stringify(records));
    displayRecentRecords();
    updateDashboard();
    showNotification('記錄已刪除', 'info');
}

// ===== Dashboard Updates =====
function updateDashboard() {
    const records = JSON.parse(localStorage.getItem('healthRecords') || '[]');
    
    if (records.length === 0) return;
    
    // Update latest values
    const latest = records[0];
    
    if (latest.weight) {
        document.getElementById('weightValue').textContent = latest.weight;
    }
    
    if (latest.heartRate) {
        document.getElementById('heartValue').textContent = latest.heartRate;
    }
    
    if (latest.sleepHours) {
        document.getElementById('sleepValue').textContent = latest.sleepHours;
    }
    
    if (latest.steps) {
        document.getElementById('stepsValue').textContent = parseInt(latest.steps).toLocaleString();
    }
    
    // Update charts with recent data
    updateCharts(records);
}

// ===== Charts Initialization =====
function initializeCharts() {
    // Create simple sparkline charts
    createSparklineChart('weightChart', [68.2, 68.5, 68.3, 68.1, 67.9, 68.0, 68.5], '#8b5cf6');
    createSparklineChart('heartChart', [70, 72, 71, 73, 72, 71, 72], '#06b6d4');
    createSparklineChart('sleepChart', [7.0, 7.2, 7.5, 7.3, 7.8, 7.6, 7.5], '#10b981');
    createSparklineChart('stepsChart', [7200, 8500, 9100, 8200, 7800, 8900, 8542], '#f59e0b');
}

function createSparklineChart(canvasId, data, color) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth * 2;
    const height = canvas.height = canvas.offsetHeight * 2;
    
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;
    
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Create gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, color + '40');
    gradient.addColorStop(1, color + '00');
    
    ctx.beginPath();
    data.forEach((value, index) => {
        const x = (index / (data.length - 1)) * width;
        const y = height - ((value - min) / range) * height * 0.8 - height * 0.1;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    // Draw line
    ctx.stroke();
    
    // Fill area under line
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();
}

function updateCharts(records) {
    // Extract last 7 days of data
    const last7Days = records.slice(0, 7).reverse();
    
    if (last7Days.length < 2) return;
    
    const weights = last7Days.map(r => parseFloat(r.weight) || 0).filter(v => v > 0);
    const heartRates = last7Days.map(r => parseInt(r.heartRate) || 0).filter(v => v > 0);
    const sleepHours = last7Days.map(r => parseFloat(r.sleepHours) || 0).filter(v => v > 0);
    const steps = last7Days.map(r => parseInt(r.steps) || 0).filter(v => v > 0);
    
    if (weights.length > 1) createSparklineChart('weightChart', weights, '#8b5cf6');
    if (heartRates.length > 1) createSparklineChart('heartChart', heartRates, '#06b6d4');
    if (sleepHours.length > 1) createSparklineChart('sleepChart', sleepHours, '#10b981');
    if (steps.length > 1) createSparklineChart('stepsChart', steps, '#f59e0b');
}

// ===== Plan Form Handling =====
function handlePlanFormSubmit(e) {
    e.preventDefault();
    
    const goal = document.getElementById('planGoalSelect').value;
    const duration = document.getElementById('planDurationInput').value;
    const intensity = document.getElementById('planIntensitySelect').value;
    const preferences = document.getElementById('planPreferencesInput').value;
    
    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span>生成中...</span>';
    submitBtn.disabled = true;
    
    // Simulate AI plan generation
    setTimeout(() => {
        const plan = generateAIPlan(goal, duration, intensity, preferences);
        savePlan(plan);
        
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        showNotification('AI 計畫已成功生成！', 'success');
        e.target.reset();
        
        // Refresh plans display
        displayPlans();
    }, 2000);
}

function generateAIPlan(goal, duration, intensity, preferences) {
    const goalNames = {
        'weight-loss': '減重計畫',
        'muscle-gain': '增肌計畫',
        'fitness': '體能提升計畫',
        'health': '整體健康計畫',
        'sleep': '睡眠改善計畫',
        'stress': '壓力管理計畫'
    };
    
    const goalDescriptions = {
        'weight-loss': '結合均衡飲食與適度運動，健康減重',
        'muscle-gain': '高蛋白飲食搭配重量訓練，有效增肌',
        'fitness': '提升心肺功能與肌力，增強體能',
        'health': '全方位健康管理，改善生活品質',
        'sleep': '優化睡眠習慣，提升睡眠品質',
        'stress': '學習放鬆技巧，有效管理壓力'
    };
    
    return {
        id: Date.now(),
        title: `${duration} 天${goalNames[goal]}`,
        description: goalDescriptions[goal],
        goal: goal,
        duration: parseInt(duration),
        intensity: intensity,
        preferences: preferences,
        startDate: new Date().toISOString(),
        progress: 0,
        active: true
    };
}

function savePlan(plan) {
    let plans = JSON.parse(localStorage.getItem('healthPlans') || '[]');
    plans.unshift(plan);
    localStorage.setItem('healthPlans', JSON.stringify(plans));
}

function displayPlans() {
    const plansGrid = document.getElementById('plansGrid');
    if (!plansGrid) return;
    
    const plans = JSON.parse(localStorage.getItem('healthPlans') || '[]');
    
    // Keep the sample plan and add user plans
    const samplePlan = plansGrid.querySelector('.plan-card');
    plansGrid.innerHTML = '';
    if (samplePlan) plansGrid.appendChild(samplePlan);
    
    plans.forEach(plan => {
        const planCard = createPlanCard(plan);
        plansGrid.appendChild(planCard);
    });
}

function createPlanCard(plan) {
    const div = document.createElement('div');
    div.className = `plan-card ${plan.active ? 'active' : ''}`;
    div.innerHTML = `
        <div class="plan-header">
            <div class="plan-badge">${plan.active ? '進行中' : '已完成'}</div>
            <button class="plan-menu-btn">⋮</button>
        </div>
        <h3 class="plan-title">${plan.title}</h3>
        <p class="plan-description">${plan.description}</p>
        <div class="plan-progress">
            <div class="progress-header">
                <span>進度</span>
                <span class="progress-percentage">${plan.progress}%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${plan.progress}%"></div>
            </div>
            <div class="progress-footer">
                <span>第 ${Math.floor(plan.duration * plan.progress / 100)} 天 / ${plan.duration} 天</span>
            </div>
        </div>
        <button class="btn btn-secondary btn-full view-plan-btn" data-plan-id="${plan.id}">查看詳情</button>
    `;
    
    div.querySelector('.view-plan-btn').addEventListener('click', () => openPlanModal(plan.id));
    
    return div;
}

// ===== Modal Handling =====
function openPlanModal(planId) {
    const modal = document.getElementById('planDetailModal');
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

function switchScheduleTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.schedule-tab').forEach(tab => {
        tab.classList.remove('active');
        if (tab.dataset.tab === tabName) {
            tab.classList.add('active');
        }
    });
    
    // Update content
    document.getElementById('dietSchedule').classList.toggle('hidden', tabName !== 'diet');
    document.getElementById('exerciseSchedule').classList.toggle('hidden', tabName !== 'exercise');
}

// ===== AI Analysis =====
function refreshAIAnalysis() {
    const btn = document.getElementById('refreshAnalysisBtn');
    btn.style.transform = 'rotate(360deg)';
    
    setTimeout(() => {
        btn.style.transform = '';
        showNotification('AI 分析已更新', 'success');
    }, 600);
}

// ===== Notifications =====
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? 'var(--success)' : type === 'error' ? 'var(--error)' : 'var(--info)'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-xl);
        z-index: 3000;
        animation: slideIn 0.3s ease-out;
        font-weight: 600;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
